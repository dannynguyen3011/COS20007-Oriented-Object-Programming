﻿using SwinAdventure;
using System;


namespace SwinAdventure
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("HelloWorld.");

        }
    }
}
